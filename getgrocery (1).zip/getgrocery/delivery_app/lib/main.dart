import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'GetGrocery Delivery',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: Colors.orange, useMaterial3: true),
        home: const Root(),
      );
}

class Root extends StatefulWidget {
  const Root({super.key});
  @override
  State<Root> createState() => _RootState();
}

class _RootState extends State<Root> {
  String? user;
  bool loaded = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final s = p.getString('session');
    final users = Map<String, dynamic>.from(jsonDecode(p.getString('users') ?? '{}'));
    setState(() {
      user = (s != null && users[s] != null) ? users[s]['name'] : null;
      loaded = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!loaded) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (user == null) return Auth(title: 'GetGrocery Delivery Partner', onDone: (n) => setState(() => user = n));
    return Jobs(user: user!, onLogout: () async {
      final p = await SharedPreferences.getInstance();
      await p.remove('session');
      setState(() => user = null);
    });
  }
}

class Jobs extends StatefulWidget {
  final String user;
  final VoidCallback onLogout;
  const Jobs({super.key, required this.user, required this.onLogout});
  @override
  State<Jobs> createState() => _JobsState();
}

class _JobsState extends State<Jobs> {
  // Demo orders. Real orders ke liye backend (Firebase/Supabase) jodna hoga.
  final List<Map<String, String>> jobs = [
    {'id': '#1001', 'addr': 'Sector 12, Market Road', 'items': 'Doodh, Bread, Ande', 'status': 'New'},
    {'id': '#1002', 'addr': 'Gandhi Nagar, Gali 4', 'items': 'Atta 5kg, Chawal 5kg', 'status': 'New'},
    {'id': '#1003', 'addr': 'Rajiv Colony, Flat 21', 'items': 'Aloo, Pyaaz, Tamatar', 'status': 'New'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Hello, ${widget.user}'), actions: [IconButton(icon: const Icon(Icons.logout), onPressed: widget.onLogout)]),
      body: ListView(padding: const EdgeInsets.all(8), children: [
        for (final j in jobs)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${j['id']}  •  ${j['status']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 4),
                Text('📍 ${j['addr']}'),
                Text('🛒 ${j['items']}'),
                const SizedBox(height: 8),
                if (j['status'] == 'New') FilledButton(onPressed: () => setState(() => j['status'] = 'Accepted'), child: const Text('Accept')),
                if (j['status'] == 'Accepted') FilledButton(onPressed: () => setState(() => j['status'] = 'Picked up'), child: const Text('Picked up')),
                if (j['status'] == 'Picked up') FilledButton(onPressed: () => setState(() => j['status'] = 'Delivered'), child: const Text('Delivered')),
              ]),
            ),
          ),
      ]),
    );
  }
}


class Auth extends StatefulWidget {
  final String title;
  final void Function(String name) onDone;
  const Auth({super.key, required this.title, required this.onDone});
  @override
  State<Auth> createState() => _AuthState();
}

class _AuthState extends State<Auth> {
  bool login = true;
  final name = TextEditingController();
  final phone = TextEditingController();
  final pass = TextEditingController();
  String err = '';

  Future<void> submit() async {
    final p = await SharedPreferences.getInstance();
    final users = Map<String, dynamic>.from(jsonDecode(p.getString('users') ?? '{}'));
    final ph = phone.text.trim();
    if (ph.length < 10 || pass.text.length < 4) {
      setState(() => err = 'Valid phone (10 digit) aur password (min 4) daalein');
      return;
    }
    if (login) {
      if (users[ph] == null || users[ph]['pass'] != pass.text) {
        setState(() => err = 'Phone ya password galat hai');
        return;
      }
    } else {
      if (name.text.trim().isEmpty) {
        setState(() => err = 'Naam daalein');
        return;
      }
      if (users[ph] != null) {
        setState(() => err = 'Ye number pehle se registered hai');
        return;
      }
      users[ph] = {'name': name.text.trim(), 'pass': pass.text};
      await p.setString('users', jsonEncode(users));
    }
    await p.setString('session', ph);
    widget.onDone(users[ph]['name']);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(24), children: [
          const SizedBox(height: 40),
          const Icon(Icons.shopping_basket, size: 72, color: Colors.green),
          Center(child: Text(widget.title, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold))),
          const SizedBox(height: 30),
          if (!login) TextField(controller: name, decoration: const InputDecoration(labelText: 'Naam', border: OutlineInputBorder())),
          if (!login) const SizedBox(height: 12),
          TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Phone number', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: pass, obscureText: true, decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder())),
          if (err.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(err, style: const TextStyle(color: Colors.red))),
          const SizedBox(height: 16),
          FilledButton(onPressed: submit, child: Padding(padding: const EdgeInsets.all(12), child: Text(login ? 'Login' : 'Register'))),
          TextButton(onPressed: () => setState(() { login = !login; err = ''; }), child: Text(login ? 'Naya account banayein' : 'Pehle se account hai? Login')),
        ]),
      ),
    );
  }
}
