# GetGrocery
- customer_app  -> GetGrocery (customer)
- delivery_app  -> GetGrocery Delivery (delivery partner)

Is repo ko GitHub par push karein -> Actions tab -> "Build APKs" -> run ke Artifacts se dono APK download karein.
