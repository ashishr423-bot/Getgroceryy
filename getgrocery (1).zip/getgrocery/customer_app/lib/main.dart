import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'GetGrocery',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: Colors.green, useMaterial3: true),
        home: const Root(),
      );
}

class Root extends StatefulWidget {
  const Root({super.key});
  @override
  State<Root> createState() => _RootState();
}

class _RootState extends State<Root> {
  String? user;
  bool loaded = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final s = p.getString('session');
    final users = Map<String, dynamic>.from(jsonDecode(p.getString('users') ?? '{}'));
    setState(() {
      user = (s != null && users[s] != null) ? users[s]['name'] : null;
      loaded = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!loaded) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (user == null) return Auth(title: 'GetGrocery', onDone: (n) => setState(() => user = n));
    return Home(user: user!, onLogout: () async {
      final p = await SharedPreferences.getInstance();
      await p.remove('session');
      setState(() => user = null);
    });
  }
}

class Home extends StatefulWidget {
  final String user;
  final VoidCallback onLogout;
  const Home({super.key, required this.user, required this.onLogout});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final List<Map<String, Object>> items = const [
    {'n': 'Doodh 1L', 'p': 60, 'e': '🥛'},
    {'n': 'Bread', 'p': 40, 'e': '🍞'},
    {'n': 'Ande (12)', 'p': 84, 'e': '🥚'},
    {'n': 'Aloo 1kg', 'p': 30, 'e': '🥔'},
    {'n': 'Pyaaz 1kg', 'p': 35, 'e': '🧅'},
    {'n': 'Tamatar 1kg', 'p': 40, 'e': '🍅'},
    {'n': 'Chawal 5kg', 'p': 320, 'e': '🍚'},
    {'n': 'Atta 5kg', 'p': 250, 'e': '🌾'},
    {'n': 'Kela (dozen)', 'p': 60, 'e': '🍌'},
    {'n': 'Seb 1kg', 'p': 180, 'e': '🍎'},
  ];
  final Map<String, int> cart = {};

  int get total {
    int t = 0;
    for (final i in items) {
      t += (i['p'] as int) * (cart[i['n']] ?? 0);
    }
    return t;
  }

  int get count => cart.values.fold(0, (a, b) => a + b);

  Future<void> checkout() async {
    final addr = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('Total: ₹$total'),
        content: TextField(controller: addr, decoration: const InputDecoration(labelText: 'Delivery address')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Order karein (COD)')),
        ],
      ),
    );
    if (ok != true || addr.text.trim().isEmpty) return;
    final p = await SharedPreferences.getInstance();
    final orders = p.getStringList('orders') ?? [];
    orders.insert(0, jsonEncode({'items': Map.of(cart), 'total': total, 'addr': addr.text.trim(), 'status': 'Placed'}));
    await p.setStringList('orders', orders);
    setState(() => cart.clear());
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Order place ho gaya!')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Namaste, ${widget.user}'), actions: [
        IconButton(icon: const Icon(Icons.receipt_long), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const Orders()))),
        IconButton(icon: const Icon(Icons.logout), onPressed: widget.onLogout),
      ]),
      body: ListView(children: [
        for (final i in items)
          ListTile(
            leading: Text(i['e'] as String, style: const TextStyle(fontSize: 32)),
            title: Text(i['n'] as String),
            subtitle: Text('₹${i['p']}'),
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
              if ((cart[i['n']] ?? 0) > 0) ...[
                IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: () => setState(() {
                  cart[i['n'] as String] = cart[i['n']]! - 1;
                  if (cart[i['n']] == 0) cart.remove(i['n']);
                })),
                Text('${cart[i['n']]}'),
              ],
              IconButton(icon: const Icon(Icons.add_circle, color: Colors.green), onPressed: () => setState(() => cart[i['n'] as String] = (cart[i['n']] ?? 0) + 1)),
            ]),
          ),
        const SizedBox(height: 80),
      ]),
      bottomNavigationBar: count == 0
          ? null
          : Padding(
              padding: const EdgeInsets.all(12),
              child: FilledButton(onPressed: checkout, child: Padding(padding: const EdgeInsets.all(12), child: Text('$count items • ₹$total • Checkout'))),
            ),
    );
  }
}

class Orders extends StatelessWidget {
  const Orders({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mere Orders')),
      body: FutureBuilder<SharedPreferences>(
        future: SharedPreferences.getInstance(),
        builder: (c, s) {
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final o = s.data!.getStringList('orders') ?? [];
          if (o.isEmpty) return const Center(child: Text('Koi order nahi'));
          return ListView(children: [
            for (final e in o)
              Card(child: ListTile(
                title: Text('₹${jsonDecode(e)['total']} • ${jsonDecode(e)['status']}'),
                subtitle: Text('${(jsonDecode(e)['items'] as Map).entries.map((x) => '${x.key} x${x.value}').join(', ')}\n${jsonDecode(e)['addr']}'),
              )),
          ]);
        },
      ),
    );
  }
}


class Auth extends StatefulWidget {
  final String title;
  final void Function(String name) onDone;
  const Auth({super.key, required this.title, required this.onDone});
  @override
  State<Auth> createState() => _AuthState();
}

class _AuthState extends State<Auth> {
  bool login = true;
  final name = TextEditingController();
  final phone = TextEditingController();
  final pass = TextEditingController();
  String err = '';

  Future<void> submit() async {
    final p = await SharedPreferences.getInstance();
    final users = Map<String, dynamic>.from(jsonDecode(p.getString('users') ?? '{}'));
    final ph = phone.text.trim();
    if (ph.length < 10 || pass.text.length < 4) {
      setState(() => err = 'Valid phone (10 digit) aur password (min 4) daalein');
      return;
    }
    if (login) {
      if (users[ph] == null || users[ph]['pass'] != pass.text) {
        setState(() => err = 'Phone ya password galat hai');
        return;
      }
    } else {
      if (name.text.trim().isEmpty) {
        setState(() => err = 'Naam daalein');
        return;
      }
      if (users[ph] != null) {
        setState(() => err = 'Ye number pehle se registered hai');
        return;
      }
      users[ph] = {'name': name.text.trim(), 'pass': pass.text};
      await p.setString('users', jsonEncode(users));
    }
    await p.setString('session', ph);
    widget.onDone(users[ph]['name']);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(24), children: [
          const SizedBox(height: 40),
          const Icon(Icons.shopping_basket, size: 72, color: Colors.green),
          Center(child: Text(widget.title, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold))),
          const SizedBox(height: 30),
          if (!login) TextField(controller: name, decoration: const InputDecoration(labelText: 'Naam', border: OutlineInputBorder())),
          if (!login) const SizedBox(height: 12),
          TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Phone number', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: pass, obscureText: true, decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder())),
          if (err.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(err, style: const TextStyle(color: Colors.red))),
          const SizedBox(height: 16),
          FilledButton(onPressed: submit, child: Padding(padding: const EdgeInsets.all(12), child: Text(login ? 'Login' : 'Register'))),
          TextButton(onPressed: () => setState(() { login = !login; err = ''; }), child: Text(login ? 'Naya account banayein' : 'Pehle se account hai? Login')),
        ]),
      ),
    );
  }
}
